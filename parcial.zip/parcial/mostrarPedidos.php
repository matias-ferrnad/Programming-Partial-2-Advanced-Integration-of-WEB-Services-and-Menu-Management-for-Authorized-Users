<!DOCTYPE html>
<html>
<head>
    <title>Mostrar Pedidos</title>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Listado de Pedidos</h2>

    <?php
    session_start();
    include "./funcs/db.php";
    $usuario = $_SESSION['usuario'];

    $queryRol = "SELECT id_rol FROM usuarios WHERE id_usuario = '$usuario'";
    $resultRol=$conn->query($queryRol);

    if ($resultRol) {
        if ($resultRol->num_rows > 0) {
            $row = $resultRol->fetch_assoc();
            $idRol = $row['id_rol'];

            if ($idRol == 1) {
                $sql = "SELECT p.id, p.cliente, p.fecha, p.comentario, m.descripcion AS menu_descripcion, l.cant
                        FROM pedidos p
                        JOIN lmenu l ON p.id = l.num_ped
                        JOIN menu m ON l.cod_menu = m.codigo
                        ORDER BY p.fecha ASC";
        
                $result = $conn->query($sql);

                if (!$result) {
                    die("Error ejecutando query:" . $conn->error);
                }
        
                if ($result->num_rows > 0) {
                    echo "<table class='table table-striped'>";
                    echo "<thead><tr><th>Número de Pedido</th><th>Cliente</th><th>Fecha</th><th>Comentario</th><th>Código de Menú</th><th>Cantidad</th></tr></thead>";
                    echo "<tbody>";
                    
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["cliente"] . "</td>";
                        echo "<td>" . $row["fecha"] . "</td>";
                        echo "<td>" . $row["comentario"] . "</td>";
                        echo "<td>" . $row["menu_descripcion"] . "</td>";
                        echo "<td>" . $row["cant"] . "</td>";
                        echo "</tr>";
                    }
                    
                    echo "</tbody>";
                    echo "</table>";
                } else {
                    echo "<p>No se encontraron pedidos.</p>";
                }
            } else {
                $sql_usuario = "SELECT p.id, p.cliente, p.fecha, p.comentario, m.descripcion AS menu_descripcion, l.cant
                    FROM pedidos p
                    JOIN lmenu l ON p.id = l.num_ped
                    JOIN menu m ON l.cod_menu = m.codigo
                    WHERE p.cliente = '$usuario'
                    ORDER BY p.fecha ASC";
        
                $result = $conn->query($sql_usuario);

                if (!$result) {
                    die("Error ejecutando query:" . $conn->error);
                }
        
                if ($result->num_rows > 0) {
                    echo "<table class='table table-striped'>";
                    echo "<thead><tr><th>Número de Pedido</th><th>Cliente</th><th>Fecha</th><th>Comentario</th><th>Código de Menú</th><th>Cantidad</th></tr></thead>";
                    echo "<tbody>";
                    
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["cliente"] . "</td>";
                        echo "<td>" . $row["fecha"] . "</td>";
                        echo "<td>" . $row["comentario"] . "</td>";
                        echo "<td>" . $row["menu_descripcion"] . "</td>";
                        echo "<td>" . $row["cant"] . "</td>";
                        echo "</tr>";
                    }
                    
                    echo "</tbody>";
                    echo "</table>";
                } else {
                    echo "<p>No se encontraron pedidos.</p>";
                }
            }
        }
    }

    $conn->close();
    ?>
</div>
</body>
</html>
