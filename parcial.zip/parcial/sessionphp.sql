-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 13, 2023 at 08:12 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sessionphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `lmenu`
--

DROP TABLE IF EXISTS `lmenu`;
CREATE TABLE IF NOT EXISTS `lmenu` (
  `num_ped` int DEFAULT NULL,
  `num` int DEFAULT NULL,
  `cod_menu` int DEFAULT NULL,
  `cant` int DEFAULT NULL,
  KEY `num_ped` (`num_ped`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lmenu`
--

INSERT INTO `lmenu` (`num_ped`, `num`, `cod_menu`, `cant`) VALUES
(0, 1, 1, 1),
(0, 2, 2, 2),
(2, 1, 1, 2),
(3, 1, 1, 1),
(3, 2, 2, 1),
(3, 3, 3, 1),
(4, 1, 1, 1),
(4, 2, 3, 2),
(5, 1, 1, 2),
(12, 1, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `codigo` int NOT NULL AUTO_INCREMENT,
  `descripcion` text,
  `precio` double DEFAULT NULL,
  `stock` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`codigo`, `descripcion`, `precio`, `stock`) VALUES
(1, 'Hamburguesa', 500, 13),
(2, 'Pizza', 150, 100),
(3, 'Asado', 1200, 0),
(4, 'Calzonne', 800, 100);

-- --------------------------------------------------------

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE IF NOT EXISTS `pedidos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cliente` varchar(50) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `comentario` text,
  PRIMARY KEY (`id`),
  KEY `cliente` (`cliente`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pedidos`
--

INSERT INTO `pedidos` (`id`, `cliente`, `fecha`, `comentario`) VALUES
(1, 'admin', '2023-11-13', '1 hamburguesa, 2 pizzas'),
(2, 'admin', '2023-11-13', '2 hamburg'),
(3, 'admin', '2023-11-13', '1 de cada'),
(4, 'usuariotest', '2023-11-13', '1H, 2A'),
(5, 'admin', '2023-11-13', ''),
(6, 'admin', '2023-11-13', ''),
(7, 'admin', '2023-11-13', 'STOCK 0'),
(8, 'admin', '2023-11-13', 'Asado stock 0, usando DIE'),
(9, 'admin', '2023-11-13', 'Asado stock 0, usando DIE y ECHO'),
(10, 'admin', '2023-11-13', 'exit(1)'),
(11, 'admin', '2023-11-13', ''),
(12, 'admin', '2023-11-13', 'ASADO 0'),
(13, 'admin', '2023-11-13', 'ultimo asado');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` varchar(50) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `clave` varchar(100) DEFAULT NULL,
  `id_rol` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `clave`, `id_rol`) VALUES
('admin', 'Administrador', '$2y$10$PY.SeAlWTQvb5oTRW3VBaul1da19MUBRPd2h3UcfGYEJtCMNOQWcq', '1'),
('usuariotest', 'usuariotest', '$2y$10$B4.EjX/8Yu4o25gKd9DxC.3af9oAcMXCueGTusvCO1UttvlDXrqaK', '3');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
