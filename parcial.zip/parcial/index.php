<?php
    session_start();
    include "./funcs/db.php";
    if(isset($_SESSION['usuario'])){
        //asd
    } else {
        header("Location: login.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Dashboard</title>
</head>
<body>
<div class="container mt-5">
    <div class="text-center"><h2>Menu Dashboard</h2></div>
    <?php
    $userRole = $_SESSION["rol"];

    $sql = "SELECT codigo, descripcion, precio, stock FROM menu";
    $result = $conn->query($sql);
    ?>

    <a href="logout.php" class="btn btn-danger">Logout</a>
    <table class="table table-bordered table-hover" aria-describedby="Tabla de menus">
        <thead class="thead-dark">
            <tr>
                <th>Código</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Stock</th>
                <?php
                if ($userRole == 1) {
                    echo '<th>Actions</th>';
                }
                ?>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>';
                    echo '<td>' . $row['codigo'] . '</td>';
                    echo '<td>' . $row['descripcion'] . '</td>';
                    echo '<td>$' . $row['precio'] . '</td>';
                    echo '<td>' . $row['stock'] . '</td>';
    
                    if ($userRole == 1) {
                        echo '<td><button type="button" class="btn btn-warning edit-menu-button" data-toggle="modal" data-target="#editMenuModal" data-menu-id="' . $row['codigo'] . '">Edit</button>';
                        echo '<br><br><a href="./funcs/delete_menu_item.php?id=' . $row['codigo'] . '" class="btn btn-danger">Delete</a>';
                    }
                    echo '</tr>';
                }
            } else {
                echo "No hay menus aún.";
            }
            ?>
        </tbody>
    </table>
    <?php if ($userRole == 1) {
        echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addMenuModal">Agregar Menu</button>';
    }
    ?>
    <a href="ordenar.php" class="btn btn-success">Ordenar</a></td>
    <a href="mostrarPedidos.php" class="btn btn-info">Mostrar Pedidos</a>
</div>

<!--  Modal Agregar Menu-->
<div class="modal fade" id="addMenuModal" tabindex="-1" role="dialog" aria-labelledby="addMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addMenuModalLabel">Nuevo menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" action="funcs/add_menu_item.php">
                    <div class="form-group">
                        <label for="descripcion">Descripción:</label>
                        <input type="text" class="form-control" id="descripcion" name="descripcion" required>
                    </div>
                    <div class="form-group">
                        <br><label for="precio">Precio:</label>
                        <input type="number" class="form-control" id="precio" name="precio" step="0.01" required>
                    </div>
                    <br><button type="submit" class="btn btn-primary">Agregar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Menu Modal -->
<div class="modal fade" id="editMenuModal" tabindex="-1" role="dialog" aria-labelledby="editMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editMenuModalLabel">Editar menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" action="funcs/edit_menu_item.php">
                    <div class="form-group">
                        <label for="new_descripcion">Descripción:</label>
                        <input type="text" class="form-control" id="new_descripcion" name="new_descripcion" required>
                    </div>
                    <div class="form-group">
                        <br><label for="new_precio">Precio:</label>
                        <input type="number" class="form-control" id="new_precio" name="new_precio" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <br><label for="new_stock">Stock:</label>
                        <input type="number" class="form-control" id="new_stock" name="new_stock" step="1" required>
                    </div>
                    <input type="hidden" id="edit_menu_id" name="menu_id">
                    <br><button type="submit" class="btn btn-primary">Guardar Cambios</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Popular con datos el modal de editar menu -->
<script>
    $(document).ready(function () {
        $(".edit-menu-button").click(function () {
            var menuId = $(this).closest("tr").find("td:eq(0)").text();
            var descripcion = $(this).closest("tr").find("td:eq(1)").text();
            var precio = $(this).closest("tr").find("td:eq(2)").text().replace('$', '');

            $("#edit_menu_id").val(menuId);
            $("#new_descripcion").val(descripcion);
            $("#new_precio").val(precio);
        });
    });
</script>

</body>
</html>
