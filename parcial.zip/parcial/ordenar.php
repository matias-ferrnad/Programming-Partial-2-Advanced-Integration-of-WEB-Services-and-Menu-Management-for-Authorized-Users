<!DOCTYPE html>
<html>
<head>
    <title>Ordenar</title>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Ordenar</h2>

    <form method="POST" action="./funcs/process_order.php" id="orderForm">
        <div class="form-group">
            <label for="menu_item">Seleccione ítems del menú:</label>
            <select class="form-control" id="menu_item" name="menu_item">
                <?php
                include "./funcs/db.php";

                $sql = "SELECT codigo, descripcion, precio, stock FROM menu";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $codigo = $row["codigo"];
                        $descripcion = $row["descripcion"];
                        $precio = $row["precio"];
                        $stock = $row["stock"];
                        echo "<option value='$codigo' data-precio='$precio'>$descripcion - Stock: $stock</option>";
                    }
                }

                $conn->close();
                ?>
            </select>
            <button type="button" class="btn btn-primary mt-2" id="addMenuItem">Agregar a la Orden</button>
            <button type="button" class="btn btn-danger mt-2" id="resetOrder">Resetear orden</button>
        </div>
        <div class="form-group">
            <label>Ítems Seleccionados:</label>
            <ul id="selectedItems"></ul>
            <p>Precio total: <span id="totalPrice">$0.00</span></p>
            <input type="hidden" id="orderData" name="orderData">
        </div>
        <div class="form-group">
            <label for="comentario">Comentario Adicional:</label>
            <textarea class="form-control" id="comentario" name="comentario"></textarea>
        </div>
        <button type="submit" class="btn btn-success">Realizar Pedido</button>
    </form>
</div>
<script>
    $(document).ready(function () {
    var selectedMenuItems = [];
    var totalPrice = 0.0;

    $("#addMenuItem").click(function () {
        var menuItem = $("#menu_item").val();
        var menuItemText = $("#menu_item option:selected").text();
        var menuItemPrice = parseFloat($("#menu_item option:selected").data("precio"));

        var existingItemIndex = selectedMenuItems.findIndex(function (item) {
            return item.codigo === menuItem;
        });

        if (existingItemIndex !== -1) {
            selectedMenuItems[existingItemIndex].cantidad += 1;
            $("#quantity_" + menuItem).text(selectedMenuItems[existingItemIndex].cantidad);
        } else {
            selectedMenuItems.push({ codigo: menuItem, descripcion: menuItemText, precio: menuItemPrice, cantidad: 1 });
            $("#selectedItems").append("<li>" + menuItemText + " - $" + menuItemPrice.toFixed(2) + " (Qty: <span id='quantity_" + menuItem + "'>1</span>) <button type='button' class='delete-item' data-menu-item='" + menuItem + "'>Delete</button></li>");
        }

        totalPrice += menuItemPrice;
        $("#totalPrice").text("$" + totalPrice.toFixed(2));
        updateOrderData();
    });

    $("#selectedItems").on("click", ".delete-item", function (event) {
        event.preventDefault();

        var menuItemCode = $(this).data("menu-item");
        var menuItemIndex = selectedMenuItems.findIndex(function (item) {
            return item.codigo === menuItemCode;
        });

        if (menuItemIndex !== -1) {
            var removedItem = selectedMenuItems[menuItemIndex];
            if (removedItem.cantidad > 1) {
                removedItem.cantidad -= 1;
                $("#quantity_" + menuItemCode).text(removedItem.cantidad);
            } else {
                selectedMenuItems.splice(menuItemIndex, 1);
                $(this).parent().remove();
            }

            totalPrice -= removedItem.precio;
            $("#totalPrice").text("$" + totalPrice.toFixed(2));
            updateOrderData();
        }
    });

    function updateOrderData() {
        var comentario = $("#comentario").val();
        $("#orderData").val(JSON.stringify({ menuItems: selectedMenuItems, comentario: comentario }));
    }

    $("#resetOrder").click(function () {
        // Reload the page to reset the order
        location.reload();
    });
});
</script>

</body>
</html>
