<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Special Menu Offers</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <!-- Custom Styles -->
    <style>
        body {
            background-color: #e6f7ff; /* Light Blue */
            color: #004080; /* Dark Blue */
        }

        .container {
            max-width: 800px;
            margin-top: 50px;
        }

        h1 {
            color: #0066cc; /* Medium Blue */
            text-align: center;
        }

        .list-group-item {
            background-color: #cce5ff; /* Lighter Blue */
            border-color: #b3d9ff; /* Border Blue */
            color: #004080; /* Dark Blue */
            font-weight: bold;
        }

        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>¡Descubre nuestras increibles ofertas!</h1>

    <div id="menuList" class="mt-4">
        <?php
        // Fetch menus using PHP
        $url = "http://localhost/parcial/webservices/menus_disponibles.php";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $menuData = curl_exec($ch);

        // Check if data is retrieved successfully
        if ($menuData) {
            // Decode JSON data
            $menus = json_decode($menuData, true);

            // Check if there are menus available
            if (!empty($menus)) {
                echo '<div class="list-group">';
                foreach ($menus as $menu) {
                    echo '<div class="list-group-item">';
                    echo '<h5 class="mb-1">' . $menu['descripcion'] . '</h5>';
                    echo '<p class="mb-1">Precio: $' . $menu['precio'] . '</p>';
                    echo '<p class="mb-1">Stock: ' . $menu['stock'] . '</p>';
                    echo '<p class="mb-1">Imagen representativa: WIP</p>';
                    echo '</div>';
                }
                echo '</div>';
            } else {
                echo '<div class="alert alert-info">No special offers available at the moment. Check back soon!</div>';
            }
        } else {
            echo '<div class="alert alert-danger">Error fetching menu data. Please try again later.</div>';
        }
        ?>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>
</html>
