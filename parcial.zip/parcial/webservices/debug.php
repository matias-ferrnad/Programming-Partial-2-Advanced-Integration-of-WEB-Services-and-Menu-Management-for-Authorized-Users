<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$url = "http://localhost/parcial/webservices/menus_disponibles.php";
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$data = curl_exec($ch);

if ($data === false) {
    echo "cURL Error: " . curl_error($ch);
    echo "cURL Error Code: " . curl_errno($ch);
}

curl_close($ch);


echo $data;
echo "a";
?>