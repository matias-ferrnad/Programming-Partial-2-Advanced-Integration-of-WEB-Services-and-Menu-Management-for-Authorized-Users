<?php
    include "../funcs/db.php";

    $select_menus_sql = "SELECT codigo, descripcion, precio, stock FROM menu WHERE stock > 0";
    $result = $conn->query($select_menus_sql);

    if ($result) {
        $menu_data = $result->fetch_all(MYSQLI_ASSOC);
        
        $conn->close();

        header('Content-Type: application/json');   
        echo json_encode($menu_data);
    } else {
        echo json_encode(array('error' => 'Error fetching menu data: ' . $conn->error));
    }

?>
