<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include "db.php";

    $id_usuario = $_SESSION['usuario'];
    $fecha = date('Y-m-d H:i:s');
    $comentario = $_POST['comentario'];

    // Extract order data from JSON
    $order_data_json = $_POST['orderData'];
    $order_data = json_decode($order_data_json, true);

    if ($order_data) {
        $conn->autocommit(false); // Start a transaction

        try {
            // Check stock before inserting main order information
            foreach ($order_data['menuItems'] as $index => $menuItem) {
                $cod_menu = $menuItem['codigo'];
                $cantidad = $menuItem['cantidad'];

                $check_stock_sql = "SELECT stock FROM menu WHERE codigo = ?";
                $stmt_check_stock = $conn->prepare($check_stock_sql);
                $stmt_check_stock->bind_param("s", $cod_menu);
                $stmt_check_stock->execute();
                $stmt_check_stock->bind_result($current_stock);
                $stmt_check_stock->fetch();
                $stmt_check_stock->close();

                if ($current_stock < $cantidad) {
                    throw new Exception("Error: No hay suficiente stock para el artículo: $cod_menu");
                }
            }

            // Insert main order information
            $insert_pedido_sql = "INSERT INTO pedidos (cliente, fecha, comentario) VALUES (?, ?, ?)";
            $stmt_pedido = $conn->prepare($insert_pedido_sql);
            $stmt_pedido->bind_param("sss", $id_usuario, $fecha, $comentario);
            $stmt_pedido->execute();

            if ($stmt_pedido->affected_rows > 0) {
                $num_ped = $stmt_pedido->insert_id;

                // Insert order details into "lmenu" table
                foreach ($order_data['menuItems'] as $index => $menuItem) {
                    $num = $index + 1;
                    $cod_menu = $menuItem['codigo'];
                    $cantidad = $menuItem['cantidad'];

                    // Update stock
                    $update_stock_sql = "UPDATE menu SET stock = stock - ? WHERE codigo = ?";
                    $stmt_update_stock = $conn->prepare($update_stock_sql);
                    $stmt_update_stock->bind_param("ss", $cantidad, $cod_menu);
                    $stmt_update_stock->execute();

                    // Insert into "lmenu" table
                    $insert_lmenu_sql = "INSERT INTO lmenu (num_ped, num, cod_menu, cant) VALUES (?, ?, ?, ?)";
                    $stmt_lmenu = $conn->prepare($insert_lmenu_sql);
                    $stmt_lmenu->bind_param("ssss", $num_ped, $num, $cod_menu, $cantidad);
                    $stmt_lmenu->execute();

                    if ($stmt_lmenu->errno) {
                        throw new Exception("Error inserting menu item: " . $stmt_lmenu->error);
                    }
                }

                // Commit the transaction
                $conn->commit();

                $conn->close();
                header("Location: success.php?num_ped=$num_ped");
                exit;
            } else {
                throw new Exception("Error insertando la orden.");
            }
        } catch (Exception $e) {
            // Rollback the transaction on error
            $conn->rollback();

            echo $e->getMessage();
        } finally {
            // Always close the connection
            $conn->close();
        }
    } else {
        echo "Error insertando tu pedido, no hay stock o el menu ya no existe más.";
        echo "<a href='../index.php'>Volver</a>";
    }
} else {
    echo "Invalid request method.";
}
?>
