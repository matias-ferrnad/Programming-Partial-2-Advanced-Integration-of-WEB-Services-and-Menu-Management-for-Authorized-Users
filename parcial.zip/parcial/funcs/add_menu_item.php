<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $descripcion = $_POST["descripcion"];
    $precio = $_POST["precio"];

    $stmt = $conn->prepare("INSERT INTO menu (descripcion, precio) VALUES (?, ?)");
    $stmt->bind_param("ss", $descripcion, $precio);

    if ($stmt->execute()) {
        header("Location: ../index.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
