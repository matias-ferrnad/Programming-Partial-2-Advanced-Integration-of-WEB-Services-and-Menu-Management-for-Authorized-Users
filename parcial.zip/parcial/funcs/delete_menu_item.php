<?php
include "db.php";

if (isset($_GET["id"]) && is_numeric($_GET["id"])) {
    $menuId = $_GET["id"];

    $sql = "DELETE FROM menu WHERE codigo = $menuId";

    if ($conn->query($sql) === TRUE) {
        header("Location: ../index.php");
        exit();
    } else {
        echo "Error deleting menu item: " . $conn->error;
    }

} else {
    echo "Invalid menu item ID.";
}

$conn->close();
?>
