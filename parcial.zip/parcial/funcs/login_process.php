<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "SELECT id_usuario, id_rol, clave FROM usuarios WHERE nombre = ? LIMIT 1";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row["clave"])) {
            session_start();
            $_SESSION["rol"] = $row["id_rol"];
            $_SESSION["usuario"] = $row["id_usuario"];
            header("Location: ../index.php");
            exit;
        } else {
            echo "Incorrect password. Please try again.";
        }
    } else {
        echo "Username not found. Please register or try a different username.";
    }

    $stmt->close();
    $conn->close();
}
?>
