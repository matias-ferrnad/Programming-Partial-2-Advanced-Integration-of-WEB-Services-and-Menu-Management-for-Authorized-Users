<!DOCTYPE html>
<html>
<head>
    <title>Orden Confirmada</title>
</head>
<body>
    <h1>Orden Confirmada</h1>
    <?php
    if (isset($_GET['num_ped'])) {
        $num_ped = $_GET['num_ped'];
        echo "<p>Número de Orden: $num_ped</p>";
        echo "$test NUMERO TEST";
    } else {
        echo "<p>Número de Orden no disponible</p>";
    }
    ?>

    <a href="../index.php">Volver a tabla de menus</a>
</body>
</html>
