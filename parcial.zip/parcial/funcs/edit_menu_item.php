<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $menuId = $_POST["menu_id"];
    $newDescripcion = $_POST["new_descripcion"];
    $newPrecio = $_POST["new_precio"];
    $newStock = $_POST["new_stock"];

    $stmt = $conn->prepare("UPDATE menu SET descripcion = ?, precio = ?, stock = ? WHERE codigo = ?");
    $stmt->bind_param("sdii", $newDescripcion, $newPrecio, $newStock, $menuId);

    if(!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    if ($stmt->execute()) {
        header("Location: ../index.php");
        exit();
    } else {
        echo "Error updating menu item: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
