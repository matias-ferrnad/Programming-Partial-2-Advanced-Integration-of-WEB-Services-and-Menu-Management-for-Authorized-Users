<?php

    include "db.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $nombre = $_POST["nombre"];
        $password = $_POST["password"];
        $default_role = 3;
    
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    
        $sql = "INSERT INTO usuarios (id_usuario, nombre, clave, id_rol) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $username, $nombre, $hashed_password, $default_role);
    
        if ($stmt->execute()) {
            header("location: ../index.php");
        } else {
            echo "Error: " . $stmt->error;
        }
    
        $stmt->close();
        $conn->close();
    }
?>
